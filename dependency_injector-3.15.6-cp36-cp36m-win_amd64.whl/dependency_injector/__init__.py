"""Dependency injector top-level package."""

__version__ = '3.15.6'
"""Version number that follows semantic versioning.

:type: str
"""
